# Voyager AI — Travel Deal Intelligence Platform

Find, scrape, and AI-analyze travel destinations to surface the best hotel deals.

## Architecture

```
User → React Frontend → Express Backend → MongoDB
                              ↓                ↑
                     AI Deal Analyzer    Playwright Scrapers
                     (Anthropic Claude)  (Hotels + Attractions)
```

## Quick Start

### Prerequisites
- Node.js 18+
- MongoDB running locally (`mongod`) or a MongoDB Atlas URI
- An Anthropic API key

### 1. Clone and install

```bash
git clone <repo>
cd travel-ai-platform

# Backend
cd backend && npm install

# Frontend
cd ../frontend && npm install

# Scraper (Playwright)
cd ../
npm install playwright
npx playwright install chromium
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env — set MONGO_URI and ANTHROPIC_API_KEY
```

### 3. Run

```bash
# From project root — starts both frontend and backend
npm run dev
```

- Frontend: http://localhost:5173
- Backend API: http://localhost:5000
- Health check: http://localhost:5000/health

### 4. Seed data (trigger your first scrape)

```bash
# With a logged-in user token:
curl -X POST http://localhost:5000/api/destinations/scrape \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"destination":"Bali","country":"Indonesia"}'
```

Or wait — the server scrapes one destination every 6 hours automatically.

---

## API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register — `{name, email, password}` |
| POST | `/api/auth/login` | Login — `{email, password}` |
| GET | `/api/auth/me` | Get current user (Bearer token) |

### Destinations
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/destinations` | Search `?q=bali&maxPrice=150&tags=beach` |
| GET | `/api/destinations/featured` | Featured destinations |
| GET | `/api/destinations/:id` | Full destination detail |
| POST | `/api/destinations/scrape` | Trigger scrape `{destination, country}` |

### AI
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/ai/best-deal?destination=Bali` | Top 5 scored hotels |
| POST | `/api/ai/compare` | Compare `{destinations:["Bali","Bangkok"], budget:100}` |

---

## How the AI Deal Scoring Works

1. **Scraper** collects hotel name, price, rating, review count, star class
2. **`aiReviewService.analyzeHotelDeals()`** sends all hotels for a destination to Claude in one batch
3. Claude scores each hotel 0–100 based on price-to-quality ratio and assigns a label
4. Scores are stored in MongoDB alongside the hotel data
5. Frontend sorts hotels by `dealScore` and displays the label + one-sentence explanation

**Deal labels:**
- `Exceptional Deal` (score 80+) — significantly better value than comparable options
- `Good Value` (60–79) — solid choice, price matches quality
- `Fair Price` (40–59) — nothing special but not a rip-off
- `Overpriced` (<40) — paying a premium without getting premium quality

---

## Project Structure

```
travel-ai-platform/
├── frontend/src/
│   ├── pages/         Home, Search, Destination, Login, Register
│   ├── components/    Navbar, SearchBar, DestinationCard, ReviewCard
│   └── services/      api.js, auth.js
├── backend/
│   ├── controllers/   authController, destinationController, aiController
│   ├── routes/        authRoutes, destinationRoutes, aiRoutes
│   ├── models/        User, Destination, Review
│   ├── middleware/    auth.js (JWT)
│   └── services/      aiReviewService, destinationService, seleniumScraper
└── scraper/
    ├── hotelsScraper.js      Booking.com via Playwright
    ├── attractionsScraper.js TripAdvisor via Playwright
    └── reviewsScraper.js     TripAdvisor reviews
```

---

## ⚠️ Important Notes

**Scraping legality:** Booking.com and TripAdvisor prohibit automated scraping in their Terms of Service. This project is for educational/portfolio purposes. For production use:
- Booking.com: Use the [Booking.com Affiliate Partner API](https://developers.booking.com)
- TripAdvisor: Use the [TripAdvisor Content API](https://developer-tripadvisor.com)

**Anti-bot measures:** Travel sites aggressively block headless browsers. If scraping stops working, sites may have updated their HTML structure or detection. The fallback attraction data prevents crashes.

**Cost:** Each AI analysis call costs ~$0.001–0.003 via the Anthropic API. The rate limiter on `/api/ai/` (10 req/min) protects against runaway costs.
