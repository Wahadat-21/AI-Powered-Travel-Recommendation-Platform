const Anthropic = require('@anthropic-ai/sdk');

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

/**
 * Score a list of hotels using AI.
 * Returns the same hotels array with dealScore, dealLabel, and aiAnalysis added.
 */
const analyzeHotelDeals = async (hotels, destinationName) => {
  if (!hotels || hotels.length === 0) return [];

  // Build a compact summary to keep token cost low
  const hotelSummaries = hotels.map((h, i) => ({
    index: i,
    name: h.name,
    pricePerNight: h.price,
    rating: h.rating,
    stars: h.stars,
    reviewCount: h.reviewCount,
    amenities: (h.amenities || []).slice(0, 5),
  }));

  const prompt = `You are a travel deal analyst. Analyze these hotels in ${destinationName} and score each one.

Hotels data:
${JSON.stringify(hotelSummaries, null, 2)}

For each hotel, provide:
1. dealScore (0-100): where 100 = exceptional value, 0 = terrible value. Consider price vs rating vs star class vs review count.
2. dealLabel: one of "Exceptional Deal", "Good Value", "Fair Price", "Overpriced"
3. aiAnalysis: one sentence (max 120 chars) explaining why

Respond ONLY with a JSON array in this exact format, no markdown:
[{"index":0,"dealScore":85,"dealLabel":"Good Value","aiAnalysis":"Strong 4-star amenities at a budget-hotel price point."},...]`;

  try {
    const response = await client.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }],
    });

    const text = response.content[0].text.trim();
    const scores = JSON.parse(text);

    // Merge AI scores back into hotels
    return hotels.map((hotel, i) => {
      const score = scores.find((s) => s.index === i) || {};
      return {
        ...hotel,
        dealScore: score.dealScore ?? 50,
        dealLabel: score.dealLabel ?? 'Fair Price',
        aiAnalysis: score.aiAnalysis ?? '',
      };
    });
  } catch (err) {
    console.error('AI deal analysis failed:', err.message);
    // Return hotels without scores rather than crash
    return hotels.map((h) => ({ ...h, dealScore: 50, dealLabel: 'Fair Price', aiAnalysis: '' }));
  }
};

/**
 * Generate an AI travel summary for a destination.
 */
const generateDestinationSummary = async (destination) => {
  const prompt = `Write a concise, honest travel recommendation for ${destination.name}, ${destination.country}.

Include:
- Best type of traveler for this destination (1 sentence)
- Top 2 things to do
- Budget guidance (based on avg hotel price: $${destination.hotels?.[0]?.price ?? 'unknown'}/night)
- One honest warning or downside

Keep it under 150 words. Be specific and useful, not generic.`;

  try {
    const response = await client.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 300,
      messages: [{ role: 'user', content: prompt }],
    });
    return response.content[0].text.trim();
  } catch (err) {
    console.error('AI summary failed:', err.message);
    return '';
  }
};

/**
 * Analyze sentiment of a user-written review.
 */
const analyzeReviewSentiment = async (reviewText) => {
  const prompt = `Analyze this travel review and respond ONLY with JSON, no markdown:
{"sentiment":"positive|neutral|negative","tags":["tag1","tag2","tag3"]}

Tags should be short descriptors like "clean rooms", "noisy", "great location", "poor service", etc. Max 5 tags.

Review: "${reviewText.slice(0, 500)}"`;

  try {
    const response = await client.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 150,
      messages: [{ role: 'user', content: prompt }],
    });
    const text = response.content[0].text.trim();
    return JSON.parse(text);
  } catch {
    return { sentiment: 'neutral', tags: [] };
  }
};

/**
 * Compare multiple destinations and pick the best deal overall.
 */
const compareTravelDeals = async (destinations, preferences = {}) => {
  const summaries = destinations.map((d) => ({
    name: d.name,
    country: d.country,
    avgHotelPrice: d.hotels?.length
      ? Math.round(d.hotels.reduce((s, h) => s + h.price, 0) / d.hotels.length)
      : null,
    topHotelScore: d.bestDealHotel?.dealScore ?? null,
    attractionCount: d.attractions?.length ?? 0,
  }));

  const prompt = `A traveler wants to compare these destinations${preferences.budget ? ` with a budget of $${preferences.budget}/night` : ''}.

Destinations:
${JSON.stringify(summaries, null, 2)}

Respond ONLY with JSON, no markdown:
{
  "recommendation": "destination name",
  "reason": "2 sentence explanation",
  "ranking": [{"name":"...","score":85,"summary":"one sentence"}]
}`;

  try {
    const response = await client.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 400,
      messages: [{ role: 'user', content: prompt }],
    });
    return JSON.parse(response.content[0].text.trim());
  } catch (err) {
    console.error('AI comparison failed:', err.message);
    return null;
  }
};

module.exports = {
  analyzeHotelDeals,
  generateDestinationSummary,
  analyzeReviewSentiment,
  compareTravelDeals,
};
