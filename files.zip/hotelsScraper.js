/**
 * Hotels Scraper
 *
 * Uses Playwright (recommended over Selenium — faster, less detectable).
 * Targets Booking.com search results.
 *
 * Install: npm install playwright
 * Then: npx playwright install chromium
 *
 * NOTE: This scraper is for educational purposes. Review Booking.com's
 * ToS before use in production. Consider their affiliate API as an alternative.
 */

const { chromium } = require('playwright');

const BOOKING_URL = 'https://www.booking.com/searchresults.html';

const scrapeHotels = async (destination, country, maxResults = 20) => {
  const browser = await chromium.launch({
    headless: process.env.HEADLESS !== 'false',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-blink-features=AutomationControlled',
    ],
  });

  const context = await browser.newContext({
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    locale: 'en-US',
    viewport: { width: 1280, height: 800 },
  });

  const page = await context.newPage();

  // Block images and fonts to speed things up
  await page.route('**/*.{png,jpg,jpeg,gif,webp,svg,woff,woff2,ttf}', (route) => route.abort());

  const hotels = [];

  try {
    const searchUrl = `${BOOKING_URL}?ss=${encodeURIComponent(`${destination}, ${country}`)}&lang=en-us&offset=0&rows=${maxResults}`;
    await page.goto(searchUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });

    // Wait for hotel cards to load
    await page.waitForSelector('[data-testid="property-card"]', { timeout: 15000 });

    const hotelCards = await page.$$('[data-testid="property-card"]');

    for (const card of hotelCards.slice(0, maxResults)) {
      try {
        const name = await card.$eval('[data-testid="title"]', (el) => el.textContent.trim()).catch(() => null);
        const priceText = await card.$eval('[data-testid="price-and-discounted-price"]', (el) => el.textContent.trim()).catch(() => null);
        const ratingText = await card.$eval('[data-testid="review-score"]', (el) => el.textContent.trim()).catch(() => null);
        const reviewCountText = await card.$eval('[data-testid="review-score-word"]', (el) => el.textContent.trim()).catch(() => null);
        const bookingUrl = await card.$eval('a[data-testid="title-link"]', (el) => el.href).catch(() => null);

        if (!name) continue;

        // Parse price — strip currency symbols and commas
        const price = priceText ? parseFloat(priceText.replace(/[^0-9.]/g, '')) : null;

        // Parse rating — Booking.com shows scores like "8.5" out of 10
        const ratingMatch = ratingText?.match(/[\d.]+/);
        const rawRating = ratingMatch ? parseFloat(ratingMatch[0]) : null;
        // Convert 10-point scale to 5-point
        const rating = rawRating ? Math.round((rawRating / 10) * 5 * 10) / 10 : null;

        hotels.push({
          name,
          price,
          currency: 'USD',
          rating,
          reviewCount: parseInt(reviewCountText?.replace(/[^0-9]/g, '') || '0'),
          stars: null, // parse from stars element if available
          amenities: [],
          bookingUrl,
          address: `${destination}, ${country}`,
        });
      } catch (err) {
        // Skip malformed cards silently
      }
    }
  } catch (err) {
    console.error(`[HotelsScraper] Failed for ${destination}:`, err.message);
  } finally {
    await browser.close();
  }

  console.log(`[HotelsScraper] ${hotels.length} hotels scraped for ${destination}`);
  return hotels;
};

module.exports = { scrapeHotels };
